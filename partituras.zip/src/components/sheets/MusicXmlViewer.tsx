"use client";

import { useEffect, useRef, useState } from "react";

type Props = {
  content: string;
  title?: string;
};

type NoteLabel = { x: number; y: number; text: string };

export default function MusicXmlViewer({ content, title }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const osmdRef = useRef<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [labels, setLabels] = useState<NoteLabel[]>([]);
  const [overlaySize, setOverlaySize] = useState({ width: 0, height: 0 });

  useEffect(() => {
    let cancelled = false;

    async function renderScore() {
      if (!containerRef.current || !content.trim()) return;

      setError(null);
      setLabels([]);
      containerRef.current.innerHTML = "";

      try {
        const { OpenSheetMusicDisplay } = await import("opensheetmusicdisplay");
        if (cancelled || !containerRef.current) return;

        const osmd = new OpenSheetMusicDisplay(containerRef.current, {
          autoResize: true,
          drawTitle: false,
          drawComposer: false,
          drawingParameters: "compacttight",
          renderSingleHorizontalStaffline: false,
        });

        osmdRef.current = osmd;
        await osmd.load(content);

        if (!cancelled) {
          osmd.render();

          // Two rAF: first for OSMD paint, second for autoResize to finish
          requestAnimationFrame(() => {
            requestAnimationFrame(() => {
              if (cancelled || !containerRef.current) return;
              try {
                const result = buildLabels(osmd, containerRef.current, content);
                if (result) {
                  setLabels(result.labels);
                  setOverlaySize(result.size);
                  hideOsmdNoteNames(containerRef.current);
                  hideOsmdNoteHeads(containerRef.current);
                  dimStaffLines(containerRef.current);
                }
              } catch (e) {
                console.warn("Note label extraction failed:", e);
              }
            });
          });
        }
      } catch (err) {
        if (!cancelled) {
          setError(
            err instanceof Error ? err.message : "No se pudo renderizar el MusicXML"
          );
        }
      }
    }

    renderScore();
    return () => { cancelled = true; };
  }, [content]);

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 md:p-8">
      {title && (
        <h2 className="font-display mb-6 text-xl font-bold text-slate-900">{title}</h2>
      )}
      {error && (
        <p className="mb-4 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-600">{error}</p>
      )}

      <div className="relative w-full">
        {/* OSMD renders its own SVG inside here */}
        <div ref={containerRef} className="musicxml-container min-h-[240px] w-full" />

        {/* Overlay SVG — completely independent from OSMD, never moves */}
        {labels.length > 0 && overlaySize.width > 0 && (
          <svg
            className="pointer-events-none absolute"
            style={{ top: 0, left: 0, zIndex: 10 }}
            width={overlaySize.width}
            height={overlaySize.height}
          >
            {labels.map((lbl, i) => (
              <text
                key={i}
                x={lbl.x}
                y={lbl.y}
                textAnchor="middle"
                dominantBaseline="middle"
                fontSize="13"
                fontWeight="800"
                fontFamily="system-ui, sans-serif"
                fill="#1e293b"
                paintOrder="stroke"
                stroke="white"
                strokeWidth="4"
                strokeLinejoin="round"
              >
                {lbl.text}
              </text>
            ))}
          </svg>
        )}
      </div>
    </div>
  );
}

// ─── Dim staff lines ──────────────────────────────────────────────────────────

function dimStaffLines(container: HTMLDivElement) {
  const svg = container.querySelector("svg");
  if (!svg) return;
  (Array.from(svg.querySelectorAll("line, path")) as SVGGraphicsElement[]).forEach((el) => {
    try {
      const b = el.getBBox();
      if (b.width > 80 && b.height <= 2) el.setAttribute("opacity", "0.15");
    } catch { /* ignore */ }
  });
}

function hideOsmdNoteNames(container: HTMLDivElement) {
  const svg = container.querySelector("svg");
  if (!svg) return;

  (Array.from(svg.querySelectorAll("text")) as SVGTextElement[]).forEach((text) => {
    const value = text.textContent?.trim() ?? "";
    if (/^[A-G](#|b)?$/.test(value)) {
      text.setAttribute("opacity", "0");
      text.setAttribute("aria-hidden", "true");
    }
  });
}

function hideOsmdNoteHeads(container: HTMLDivElement) {
  const svg = container.querySelector("svg");
  if (!svg) return;

  findNoteHeadEllipses(svg).forEach((ellipse) => {
    ellipse.setAttribute("opacity", "0");
    ellipse.setAttribute("aria-hidden", "true");
  });
}

// ─── Note name list from MusicXML ─────────────────────────────────────────────

function parseNoteNames(musicXml: string): string[] {
  let doc: Document;
  try {
    doc = new DOMParser().parseFromString(musicXml, "application/xml");
  } catch { return []; }

  const names: string[] = [];
  doc.querySelectorAll("note").forEach((note) => {
    if (note.querySelector("rest")) return;
    const step = note.querySelector("pitch > step")?.textContent?.trim();
    if (!step) return;
    const alter = parseInt(note.querySelector("pitch > alter")?.textContent?.trim() ?? "0", 10);
    const acc = alter === 1 ? "#" : alter === -1 ? "b" : "";
    names.push(`${step}${acc}`);
  });
  return names;
}

// ─── Find note-head elements in OSMD's SVG ────────────────────────────────────
//
// OSMD renders note heads as <ellipse> elements.
// We sort them in reading order: top-to-bottom row, left-to-right within each row.

function findNoteHeadEllipses(svg: SVGSVGElement): SVGEllipseElement[] {
  const ellipses = Array.from(svg.querySelectorAll("ellipse")) as SVGEllipseElement[];

  // Sort: group by vertical band (row), then by x within each row
  ellipses.sort((a, b) => {
    try {
      const ba = a.getBBox();
      const bb = b.getBBox();
      const rowThreshold = Math.max(ba.height, bb.height, 4) * 3;
      if (Math.abs(ba.y - bb.y) > rowThreshold) return ba.y - bb.y;
      return ba.x - bb.x;
    } catch { return 0; }
  });

  return ellipses;
}

// ─── Main: build label list ───────────────────────────────────────────────────

function buildLabels(
  _osmd: any,
  container: HTMLDivElement,
  musicXml: string,
): { labels: NoteLabel[]; size: { width: number; height: number } } | null {
  const svg = container.querySelector("svg");
  if (!svg) return null;

  const noteNames = parseNoteNames(musicXml);
  if (noteNames.length === 0) return null;

  const ellipses = findNoteHeadEllipses(svg);
  if (ellipses.length === 0) return null;

  // Compute scale: SVG viewBox units → actual CSS pixels
  const svgRect = svg.getBoundingClientRect();
  const containerRect = container.getBoundingClientRect();
  const viewBox = svg.viewBox.baseVal;

  const scaleX = viewBox.width > 0 ? svgRect.width / viewBox.width : 1;
  const scaleY = viewBox.height > 0 ? svgRect.height / viewBox.height : 1;

  // Offset: position of SVG within the container div
  const offsetX = svgRect.left - containerRect.left;
  const offsetY = svgRect.top - containerRect.top;

  const count = Math.min(ellipses.length, noteNames.length);
  const labels: NoteLabel[] = [];

  for (let i = 0; i < count; i++) {
    try {
      const box = ellipses[i].getBBox();
      labels.push({
        // Center of the note head ellipse, converted to container-relative px
        x: (box.x + box.width / 2) * scaleX + offsetX,
        y: (box.y + box.height / 2) * scaleY + offsetY,
        text: noteNames[i],
      });
    } catch { /* getBBox can throw on hidden elements */ }
  }

  return {
    labels,
    size: {
      width: containerRect.width,
      height: svgRect.height + offsetY,
    },
  };
}
